package com.oracle.Ojakgyo.dao;

import java.util.List;

import com.oracle.Ojakgyo.model.Donation;
import com.oracle.Ojakgyo.model.TBoard;
import com.oracle.Ojakgyo.model.Taxi;

public interface BoardDAO {

	List<Taxi> taxiList();

	List<Donation> DoList();
	
}
