package com.oracle.Ojakgyo.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.oracle.Ojakgyo.model.Estate;
import com.oracle.Ojakgyo.model.Taxi;

@Repository
public class EstateDAOImp implements EstateDAO {

	@Autowired
	private SqlSession session;

	@Override
	public List<Estate> estateList() {
		return session.selectList("estateList");
	}

	
}
