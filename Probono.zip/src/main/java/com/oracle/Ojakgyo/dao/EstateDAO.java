package com.oracle.Ojakgyo.dao;

import java.util.List;

import com.oracle.Ojakgyo.model.Estate;

public interface EstateDAO {

	List<Estate> estateList();

}
