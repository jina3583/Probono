package com.oracle.Ojakgyo.model;

public class Estate {
	private int e_id;
	private String e_title;
	private String e_price;
	private String e_area;
	private String e_type;
	private String e_build;
	private String e_content;
	private String e_address;
	private String e_goo;
	private String e_dong;
	private String e_floor;
	private String e_room;
	private String e_move;
	private String e_updated;
	private String e_joongae;
	
	public int getE_id() {
		return e_id;
	}
	public void setE_id(int e_id) {
		this.e_id = e_id;
	}
	public String getE_title() {
		return e_title;
	}
	public void setE_title(String e_title) {
		this.e_title = e_title;
	}
	public String getE_price() {
		return e_price;
	}
	public void setE_price(String e_price) {
		this.e_price = e_price;
	}
	public String getE_area() {
		return e_area;
	}
	public void setE_area(String e_area) {
		this.e_area = e_area;
	}
	public String getE_type() {
		return e_type;
	}
	public void setE_type(String e_type) {
		this.e_type = e_type;
	}
	public String getE_build() {
		return e_build;
	}
	public void setE_build(String e_build) {
		this.e_build = e_build;
	}
	public String getE_content() {
		return e_content;
	}
	public void setE_content(String e_content) {
		this.e_content = e_content;
	}
	public String getE_address() {
		return e_address;
	}
	public void setE_address(String e_address) {
		this.e_address = e_address;
	}
	public String getE_goo() {
		return e_goo;
	}
	public void setE_goo(String e_goo) {
		this.e_goo = e_goo;
	}
	public String getE_dong() {
		return e_dong;
	}
	public void setE_dong(String e_dong) {
		this.e_dong = e_dong;
	}
	public String getE_floor() {
		return e_floor;
	}
	public void setE_floor(String e_floor) {
		this.e_floor = e_floor;
	}
	public String getE_room() {
		return e_room;
	}
	public void setE_room(String e_room) {
		this.e_room = e_room;
	}
	public String getE_move() {
		return e_move;
	}
	public void setE_move(String e_move) {
		this.e_move = e_move;
	}
	public String getE_updated() {
		return e_updated;
	}
	public void setE_updated(String e_updated) {
		this.e_updated = e_updated;
	}
	public String getE_joongae() {
		return e_joongae;
	}
	public void setE_joongae(String e_joongae) {
		this.e_joongae = e_joongae;
	}
	
}
