package com.oracle.Ojakgyo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.oracle.Ojakgyo.dao.BoardDAO;
import com.oracle.Ojakgyo.dao.EstateDAO;
import com.oracle.Ojakgyo.model.Estate;
import com.oracle.Ojakgyo.model.Taxi;

@Service
public class EstateServiceImp implements EstateService {
	
	@Autowired
	private EstateDAO ed;

	@Override
	public List<Estate> estateList() {
		return ed.estateList();
	}

	
}
