package com.oracle.Ojakgyo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.oracle.Ojakgyo.dao.BoardDAO;
import com.oracle.Ojakgyo.model.Donation;
import com.oracle.Ojakgyo.model.TBoard;
import com.oracle.Ojakgyo.model.Taxi;

@Service
public class BoardServiceImp implements BoardService {

	@Autowired
	private BoardDAO bd;

	@Override
	public List<Taxi> taxiList() {
		return bd.taxiList();
	}

	@Override
	public List<Donation> DoList() {
		return bd.DoList();
	}

	
}
