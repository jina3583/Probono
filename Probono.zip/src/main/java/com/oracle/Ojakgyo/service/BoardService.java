package com.oracle.Ojakgyo.service;

import java.util.List;

import com.oracle.Ojakgyo.model.Donation;
import com.oracle.Ojakgyo.model.TBoard;
import com.oracle.Ojakgyo.model.Taxi;

public interface BoardService {

	List<Taxi> taxiList();

	List<Donation> DoList();

}
