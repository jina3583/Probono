package com.oracle.Ojakgyo.service;

import java.util.List;

import com.oracle.Ojakgyo.model.Estate;

public interface EstateService {

	List<Estate> estateList();

}
