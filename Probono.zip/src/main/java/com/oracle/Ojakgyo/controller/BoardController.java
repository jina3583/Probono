package com.oracle.Ojakgyo.controller;



import java.util.List;


import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.oracle.Ojakgyo.model.Donation;
import com.oracle.Ojakgyo.model.Taxi;
import com.oracle.Ojakgyo.service.BoardService;

@Controller
public class BoardController {

	@Autowired
	private BoardService bs;
	
	@RequestMapping("taxi")
	public String taxi(Model model) {
		List<Taxi> taxi_List = bs.taxiList();
		model.addAttribute("taxi",taxi_List);
		return "taxi";
	}
	
	@RequestMapping("donation")
	public String donation(Model model) {
		List<Donation> Do_List=bs.DoList();
		model.addAttribute("Donation",Do_List);
		return "donation";
	}
	
	
}
