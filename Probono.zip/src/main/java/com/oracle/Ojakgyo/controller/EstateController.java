package com.oracle.Ojakgyo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.oracle.Ojakgyo.model.Estate;
import com.oracle.Ojakgyo.model.Taxi;
import com.oracle.Ojakgyo.service.BoardService;
import com.oracle.Ojakgyo.service.EstateService;

@Controller
public class EstateController {

	@Autowired
	private EstateService es;
	
	@RequestMapping("estate")
	public String taxi(Model model) {
		List<Estate> list_estate = es.estateList();
		model.addAttribute("list",list_estate);
		return "estate";
	}
}
